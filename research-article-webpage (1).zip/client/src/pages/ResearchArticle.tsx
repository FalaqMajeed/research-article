import { useState, useEffect } from 'react';
import { Menu, X } from 'lucide-react';
import Sidebar from '@/components/Sidebar';
import Footer from '@/components/Footer';

/**
 * ResearchArticle Page - Premium Academic Design
 * 
 * Main research article page with:
 * - Responsive sidebar navigation
 * - Complete article content with refined typography
 * - Elegant section headers and styling
 * - Professional data tables
 * - Mobile-responsive layout
 */

export default function ResearchArticle() {
  const [activeSection, setActiveSection] = useState('abstract');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const sections = [
    { id: 'abstract', title: 'Abstract' },
    { id: 'introduction', title: 'Introduction' },
    { id: 'methodology', title: 'Methodology' },
    { id: 'results', title: 'Results & Analysis' },
    { id: 'discussion', title: 'Discussion' },
    { id: 'conclusion', title: 'Conclusion' },
  ];

  const handleNavClick = (sectionId: string) => {
    setActiveSection(sectionId);
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    setMobileMenuOpen(false);
  };

  useEffect(() => {
    const handleScroll = () => {
      const sectionIds = ["abstract", "introduction", "methodology", "results", "discussion", "conclusion"];
      let current = "abstract";

      for (const id of sectionIds) {
        const el = document.getElementById(id);
        if (el) {
          const rect = el.getBoundingClientRect();
          if (rect.top <= 150) {
            current = id;
          }
        }
      }

      setActiveSection(current);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <div className="flex min-h-screen bg-background">
      {/* Desktop Sidebar */}
      <div className="hidden lg:block w-80 sticky top-0 h-screen border-r border-border bg-card overflow-y-auto">
        <Sidebar sections={sections} activeSection={activeSection} onNavClick={handleNavClick} />
      </div>

      {/* Mobile Menu Button */}
      <button
        onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
        className="lg:hidden fixed top-6 left-6 z-50 p-2 rounded-sm bg-card border border-border hover:bg-secondary shadow-sm transition-colors"
        aria-label="Toggle navigation menu"
      >
        {mobileMenuOpen ? <X size={20} className="text-foreground" /> : <Menu size={20} className="text-foreground" />}
      </button>

      {/* Mobile Sidebar */}
      {mobileMenuOpen && (
        <div className="lg:hidden fixed inset-0 z-40 bg-black/50" onClick={() => setMobileMenuOpen(false)}>
          <div className="w-72 h-screen bg-card border-r border-border overflow-y-auto">
            <Sidebar sections={sections} activeSection={activeSection} onNavClick={handleNavClick} />
          </div>
        </div>
      )}

      {/* Main Content */}
      <div className="flex-1 flex flex-col">
        <main className="flex-1 px-6 sm:px-8 lg:px-12 py-12 lg:py-16 max-w-4xl mx-auto w-full">
          {/* Article Header */}
          <div className="mb-16 pt-4">
            <h1 className="text-6xl font-bold text-foreground mb-4 text-center" style={{ fontFamily: "'Crimson Text', serif" }}>
              Performance Gains, Behavioral Losses
            </h1>
            <p className="text-2xl text-muted-foreground mb-8 leading-relaxed text-center">
              A Study of Sycophancy in Benchmark-Optimized Language Models
            </p>

            {/* Authors */}
            <div className="py-8 border-y border-border text-center">
              <p className="text-lg text-foreground">Linah Khayri and Falag Abdulmajeed</p>
            </div>
          </div>

          {/* Abstract Section */}
          <section id="abstract" className="article-content mb-20">
            <h2 className="text-4xl font-bold text-foreground mb-8 pb-4 border-l-4 border-primary pl-6" style={{ fontFamily: "'Crimson Text', serif" }}>
              Abstract
            </h2>
            <p>
              Sycophancy in language models, where a system aligns its answers with a user's beliefs even when those beliefs are incorrect, is an important challenge for alignment and truthfulness. As performance on large capability benchmarks becomes a primary focus, an uneasy tension emerges: the metrics driving progress may also steer models toward agreeable compliance rather than independent reasoning. Early work has already linked this tendency to reinforcement learning from human feedback (RLHF).
            </p>
            <p>
              This project investigates how benchmark-driven fine-tuning shapes sycophantic behavior by comparing a baseline model with several single-benchmark LoRA adapters and a combined multitask adapter. Our results show that some benchmarks consistently increase agreement bias, while others have little effect. These patterns suggest that improvements in benchmark performance can coincide with reduced reasoning autonomy and weaker grounding in factual accuracy.
            </p>
            <p className="italic text-muted-foreground">
              This leaves a larger question for the field: What unintended behaviors might we be training into our systems as we optimize for the scores we trust most?
            </p>
          </section>

          {/* Introduction Section */}
          <section id="introduction" className="article-content mb-20">
            <h2 className="text-4xl font-bold text-foreground mb-8 pb-4 border-l-4 border-primary pl-6" style={{ fontFamily: "'Crimson Text', serif" }}>
              Introduction: The Misalignment of Metrics
            </h2>

            <h3 className="text-2xl font-bold text-foreground mt-10 mb-6" style={{ fontFamily: "'Crimson Text', serif" }}>
              The Established View: RLHF as the Primary Culprit
            </h3>
            <p>
              The prevailing narrative surrounding language model sycophancy identifies Reinforcement Learning from Human Feedback (RLHF) as the primary mechanism responsible. During this critical training phase, models learn to maximize human preference signals, often simple thumbs-up or thumbs-down ratings. While RLHF successfully enhances essential traits like helpfulness and coherence, it unintentionally amplifies non-essential, manipulative behaviors.
            </p>
            <p>
              Quantitative evidence robustly supports this claim: studies have consistently found that "matching the user's belief" is the single most reliable predictor of human preference, even after controlling for objective measures of truthfulness and helpfulness. The very mechanism designed to enhance model safety and usability inadvertently creates an incentive structure where flattery and conformity reliably boost positive ratings, effectively teaching the model that agreement is a high-value output.
            </p>

            <h3 className="text-2xl font-bold text-foreground mt-10 mb-6" style={{ fontFamily: "'Crimson Text', serif" }}>
              The Critical Insight: Beyond High-Level Training
            </h3>
            <p>
              However, this fixation on RLHF as the sole cause risks overlooking more fundamental, structural drivers that operate earlier in the development pipeline. The conversation has largely centered on the mechanism of reward (RLHF), but perhaps the problem begins with the objective of optimization. What if the push for state-of-the-art performance, separate from human feedback loops, also subtly encourages sycophantic behavior?
            </p>

            <h3 className="text-2xl font-bold text-foreground mt-10 mb-6" style={{ fontFamily: "'Crimson Text', serif" }}>
              Benchmarks: From Passive Metrics to Behavioral Architects
            </h3>
            <p>
              The modern development cycle for language models is defined by a relentless push to climb performance leaderboards, measured by broad capability benchmarks such as MMLU, GSM8K, TruthfulQA, and HellaSwag. Commonly these benchmarks are treated as neutral scorecards, objective tools for measuring progress and cognitive capacity. Yet, they are far from passive observers; they function as powerful behavioral architects that actively shape how a model reasons at nearly every stage of development.
            </p>
            <p>
              This creates a troubling structural possibility: our focus on maximizing scores on these general benchmarks may inadvertently establish its own deep-seated incentive structure, one that rewards answer conformity and pattern matching in ways early similar to RLHF's approval-driven cycles. When we fine-tune for top GSM8K scores, we are teaching models highly specialized mathematical reasoning. When we prioritize MMLU, we are maximizing the breadth and retrieval of factual knowledge. We rarely pause to ask: what behavioral side effects accompany these structural specializations?
            </p>

            <h3 className="text-2xl font-bold text-foreground mt-10 mb-6" style={{ fontFamily: "'Crimson Text', serif" }}>
              The Benchmark-Sycophancy Paradox
            </h3>
            <p>
              Consider the paradox this creates: the field uses specialized sycophancy benchmarks (like SycophancyEval) to detect and measure conformity, while simultaneously pushing models to excel at general benchmarks that may inadvertently cultivate the very behaviors we are trying to eliminate. This raises a critical and previously overlooked question: could benchmark-driven fine-tuning itself be a previously overlooked, fundamental source of sycophancy?
            </p>
          </section>

          {/* Methodology Section */}
          <section id="methodology" className="article-content mb-20">
            <h2 className="text-4xl font-bold text-foreground mb-8 pb-4 border-l-4 border-primary pl-6" style={{ fontFamily: "'Crimson Text', serif" }}>
              Methodology: Isolating Benchmark-Driven Sycophancy
            </h2>
            <p>
              Our study utilizes a controlled experimental design to systematically isolate the direct impact of benchmark-specific fine-tuning on sycophantic behavior. While acknowledging the inherent complexities of model alignment, our methodology provides a granular framework for observing behavioral changes tied to distinct optimization objectives. The insights generated aim to illuminate potential risks and serve as a foundation for future, more extensive investigations into alignment degradation.
            </p>

            <h3 className="text-2xl font-bold text-foreground mt-10 mb-6" style={{ fontFamily: "'Crimson Text', serif" }}>
              Fine-tuning Procedure: Model and Adapters
            </h3>
            <p>
              To understand precisely how fine-tuning influences sycophantic tendencies, we first established a baseline and created five Low-Rank Adaptation (LoRA) adapters.
            </p>
            <p className="font-semibold text-foreground mt-6">Base Model:</p>
            <p>
              We selected the Llama-2-7B-Chat model as our foundation, providing a strong, instruction-tuned baseline against which all sycophancy shifts are measured.
            </p>
            <p className="font-semibold text-foreground mt-6">LoRA Adapters:</p>
            <p>
              We employed Low-Rank Adaptation (LoRA) for efficient fine-tuning. This technique is critical because it allows us to freeze the original model weights and only train small, low-rank matrices (adapters). This isolates the behavioral changes specifically to the targeted benchmark data, rather than introducing overall full-model drift.
            </p>
            <p className="font-semibold text-foreground mt-6">Experimental Adapters:</p>
            <p>We constructed five distinct model adapters. All were trained using identical hyperparameters (batch size, learning rate, and epoch count) to ensure rigorous comparability:</p>
            <ul className="list-disc list-inside space-y-2 mt-4 ml-4">
              <li>Baseline Control (Llama-2-7B-Chat): The original instruction-tuned model</li>
              <li>MMLU Adapter (Massive Multitask Language Understanding)</li>
              <li>GSM8K Adapter (Grade School Math 8K)</li>
              <li>TruthfulQA Adapter</li>
              <li>HellaSwag Adapter</li>
              <li>Multitask Adapter: Trained on balanced combination of all four benchmarks</li>
            </ul>

            <h3 className="text-2xl font-bold text-foreground mt-10 mb-6" style={{ fontFamily: "'Crimson Text', serif" }}>
              Evaluation Framework
            </h3>
            <p>
              We built a two-stage evaluation pipeline designed to measure the model's performance on the target benchmarks and its vulnerability to user-stated beliefs.
            </p>
            <p className="font-semibold text-foreground mt-6">Baseline Capability Evaluation:</p>
            <p>
              All five models were first evaluated on a standard set of reasoning and knowledge tasks. Establishing quantitative improvements in arithmetic reasoning (GSM8K), commonsense inference (HellaSwag), general knowledge (MMLU), and factuality (TruthfulQA) is necessary to confirm that the fine-tuning was successful before analyzing any behavioral side effects.
            </p>
            <p className="font-semibold text-foreground mt-6">Sycophancy Inspection Tasks:</p>
            <p>
              We constructed prompt templates based on the SycophancyEval framework. The same core question is embedded under three specific user framings to measure deviation from the objective truth:
            </p>
            <ul className="list-disc list-inside space-y-2 mt-4 ml-4">
              <li>User expresses a belief that is correct</li>
              <li>User expresses a belief that is incorrect</li>
              <li>User expresses no belief (Neutral baseline for correctness)</li>
            </ul>
          </section>

          {/* Results Section */}
          <section id="results" className="article-content mb-20">
            <h2 className="text-4xl font-bold text-foreground mb-8 pb-4 border-l-4 border-primary pl-6" style={{ fontFamily: "'Crimson Text', serif" }}>
              Results & Analysis
            </h2>

            <h3 className="text-2xl font-bold text-foreground mt-10 mb-6" style={{ fontFamily: "'Crimson Text', serif" }}>
              Baseline Evaluation
            </h3>
            <p>
              The baseline model was evaluated on four common capability benchmarks representing mathematical reasoning, multitask knowledge, truthfulness, and commonsense reasoning.
            </p>

            <div className="overflow-x-auto my-8">
              <table className="academic-table">
                <thead>
                  <tr>
                    <th>Benchmark</th>
                    <th>Description</th>
                    <th>Test Samples</th>
                    <th>Baseline Score</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>GSM8K</td>
                    <td>Grade-school math reasoning</td>
                    <td>500</td>
                    <td>0.07</td>
                  </tr>
                  <tr>
                    <td>MMLU</td>
                    <td>Multitask language understanding</td>
                    <td>500</td>
                    <td>0.38</td>
                  </tr>
                  <tr>
                    <td>TruthfulQA</td>
                    <td>Truthfulness and informativeness</td>
                    <td>200</td>
                    <td>0.385</td>
                  </tr>
                  <tr>
                    <td>HellaSwag</td>
                    <td>Commonsense reasoning</td>
                    <td>500</td>
                    <td>0.734</td>
                  </tr>
                </tbody>
              </table>
            </div>

            <p>
              The model exhibits weak mathematical reasoning and moderate multitask knowledge, which aligns with expectations for a 7B base model. However, the TruthfulQA score (38.5%) indicates limited robustness against misleading or false prompts, and the high HellaSwag score (73.4%) highlights stronger commonsense completion performance.
            </p>

            <h3 className="text-2xl font-bold text-foreground mt-10 mb-6" style={{ fontFamily: "'Crimson Text', serif" }}>
              Baseline Sycophancy Evaluation
            </h3>
            <p>
              Three evaluation suites were used to measure the model's tendency to align with incorrect user claims:
            </p>

            <div className="overflow-x-auto my-8">
              <table className="academic-table">
                <thead>
                  <tr>
                    <th>Evaluation Suite</th>
                    <th>Agreement Score</th>
                    <th>Sycophantic Responses</th>
                    <th>Total Cases</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>Feedback</td>
                    <td className="text-accent font-semibold">0.50</td>
                    <td>150</td>
                    <td>300</td>
                  </tr>
                  <tr>
                    <td>Are-You-Sure</td>
                    <td className="text-accent font-semibold">0.00</td>
                    <td>0</td>
                    <td>300</td>
                  </tr>
                  <tr>
                    <td>Answer</td>
                    <td className="text-accent font-semibold">0.1767</td>
                    <td>53</td>
                    <td>300</td>
                  </tr>
                </tbody>
              </table>
            </div>

            <p>
              The model shows a notable agreement bias in the Feedback suite, where half of responses aligned with incorrect user assertions. The Answer suite indicates a milder but still present susceptibility. In contrast, the Are-You-Sure suite shows no sycophantic behavior, suggesting the model is willing to push back on confidently incorrect claims when prompted directly.
            </p>

            <h3 className="text-2xl font-bold text-foreground mt-10 mb-6" style={{ fontFamily: "'Crimson Text', serif" }}>
              Post-Fine-Tuning Results
            </h3>
            <p>
              The following results show how each single-benchmark LoRA adapter and the combined multitask adapter shifted both capability performance and sycophancy behavior relative to the baseline model.
            </p>

            <figure className="my-12">
              <img 
                src="/images/benchmark-performance-plots.png" 
                alt="Benchmark Performance Comparison Charts" 
                className="w-full rounded-sm border border-border shadow-sm"
              />
              <figcaption className="text-sm text-muted-foreground mt-4 text-center italic">
                Figure 1: Comparative benchmark performance across baseline, GSM8K, MMLU, TruthfulQA, HellaSwag, and combined multitask adapters.
              </figcaption>
            </figure>

            <figure className="my-12">
              <img 
                src="/images/sycophancy-impact-plots.png" 
                alt="Sycophancy Impact Across All Fine-Tuned Adapters" 
                className="w-full rounded-sm border border-border shadow-sm"
              />
              <figcaption className="text-sm text-muted-foreground mt-4 text-center italic">
                Figure 2: Sycophancy impact across all fine-tuned adapters compared with baseline. Higher values indicate increased sycophancy.
              </figcaption>
            </figure>

          </section>

          {/* Discussion Section */}
          <section id="discussion" className="article-content mb-20">
            <h2 className="text-4xl font-bold text-foreground mb-8 pb-4 border-l-4 border-primary pl-6" style={{ fontFamily: "'Crimson Text', serif" }}>
              Discussion
            </h2>
            <p>
              Our findings reveal a complex relationship between benchmark-driven fine-tuning and sycophantic behavior. While some benchmarks (GSM8K) appear to reduce agreement bias, others (TruthfulQA, HellaSwag) show concerning increases in sycophancy metrics, particularly in conversational contexts.
            </p>
            <p>
              The most striking result is the TruthfulQA paradox: optimizing for truthfulness can increase sycophancy in other contexts. This suggests a potential trade-off: optimizing for factual accuracy on a specific benchmark may inadvertently teach models to prioritize user agreement in other evaluation frameworks. This paradox warrants further investigation into the mechanisms by which fine-tuning objectives propagate behavioral changes across different evaluation frameworks.
            </p>
            <p>
              The HellaSwag adapter's increased sycophancy despite modest performance improvements suggests that not all benchmarks equally drive behavioral changes. Commonsense reasoning optimization appears to correlate with increased compliance, possibly because commonsense tasks often involve implicit social reasoning that models may learn to align with perceived user expectations.
            </p>
            <p>
              The multitask adapter's mixed results suggest that balanced optimization across multiple objectives may provide some protection against extreme sycophancy increases, though it does not eliminate the phenomenon entirely. This finding has important implications for development practices: single-objective fine-tuning may pose greater alignment risks than multi-objective approaches.
            </p>
            <p>
              These results support the hypothesis that benchmark-driven fine-tuning itself—independent of RLHF—can be a significant source of sycophantic behavior. This challenges the field's implicit assumption that general capability benchmarks are neutral measurement tools. Instead, they function as behavioral architects that actively shape model reasoning in ways that may conflict with alignment goals.
            </p>
          </section>

          {/* Conclusion Section */}
          <section id="conclusion" className="article-content mb-20">
            <h2 className="text-4xl font-bold text-foreground mb-8 pb-4 border-l-4 border-primary pl-6" style={{ fontFamily: "'Crimson Text', serif" }}>
              Conclusion
            </h2>
            <p>
              This study provides evidence that benchmark-driven fine-tuning shapes sycophantic behavior in language models, independent of RLHF mechanisms. Our controlled experimental design isolates the direct impact of single-benchmark optimization, revealing that some benchmarks consistently increase agreement bias while others have minimal effect.
            </p>
            <p>
              The most critical finding is the TruthfulQA paradox: optimizing for truthfulness can increase sycophancy in other contexts. This suggests that the field's reliance on narrow capability benchmarks may inadvertently cultivate the very behavioral misalignment we seek to prevent. As we push models toward higher benchmark scores, we may simultaneously be training them toward greater compliance and reduced reasoning autonomy.
            </p>
            <p>
              These findings raise important questions for future research:
            </p>
            <ul className="list-disc list-inside space-y-3 mt-6 ml-4">
              <li>How do different fine-tuning objectives propagate behavioral changes across evaluation frameworks?</li>
              <li>Can we design benchmarks that measure capability without inadvertently incentivizing sycophancy?</li>
              <li>What role do model architecture and scale play in mediating these effects?</li>
              <li>How can we balance performance improvements with alignment and behavioral integrity?</li>
            </ul>
            <p className="mt-8">
              We hope this work catalyzes a broader conversation in the field about the hidden costs of benchmark optimization. As language models become more capable and more widely deployed, understanding and mitigating unintended behavioral side effects becomes increasingly critical. The metrics we optimize for today shape the systems we deploy tomorrow—and we must be intentional about what behaviors we are implicitly training into our models.
            </p>
          </section>


        </main>

        {/* Footer */}
        <Footer />
      </div>
    </div>
  );
}
